UDM_10 – QA Evidence Package
================================

This package is prepared from the existing QA artifacts and the GUI result observed in the conversation.

IMPORTANT:
- It does NOT fabricate test evidence.
- Existing automated/unit/TCP results are preserved.
- The GUI screenshot showing one PDF reaching 100% / Hoàn tất must be saved by the tester under:
  01_Screenshots/TC-27/TC-27_upload_success.png
- TC-27 is marked PARTIAL because upload success was observed, but the required history persistence fields were not independently verified.
- TC-28, TC-29, TC-30 and TC-32 remain NOT EXECUTED until actually tested.
- TC-31 remains PARTIAL.
- TC-33 is N/A according to the existing report.

Included:
01_Screenshots/  Evidence images by test case
02_Logs/          Server/client logs
03_Data/          Existing CSV/manifest and test-result artifacts
04_Hash/          Hash area
05_Report/        Master Excel + existing DOCX report

Recommended final workflow:
1. Save real screenshots into the matching TC folders.
2. Export/copy real logs into 02_Logs.
3. Run the remaining GUI/end-to-end tests.
4. Recalculate SHA-256 after all evidence is added.
5. Update the master Excel.
6. Zip this folder for submission/Git.
